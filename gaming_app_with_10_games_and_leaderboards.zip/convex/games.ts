import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Initialize games data
export const initializeGames = mutation({
  args: {},
  handler: async (ctx) => {
    const existingGames = await ctx.db.query("games").collect();
    if (existingGames.length > 0) return;

    const games = [
      { name: "Memory Match", description: "اختبر ذاكرتك بمطابقة البطاقات", icon: "🧠", category: "memory" },
      { name: "Number Puzzle", description: "حل الألغاز الرقمية", icon: "🔢", category: "puzzle" },
      { name: "Word Scramble", description: "رتب الحروف لتكوين كلمات", icon: "📝", category: "word" },
      { name: "Color Match", description: "طابق الألوان بسرعة", icon: "🎨", category: "reflex" },
      { name: "Math Quiz", description: "اختبر مهاراتك في الرياضيات", icon: "➕", category: "math" },
      { name: "Pattern Recognition", description: "تعرف على الأنماط", icon: "🔍", category: "pattern" },
      { name: "Speed Typing", description: "اكتب بأسرع ما يمكن", icon: "⌨️", category: "typing" },
      { name: "Logic Puzzle", description: "حل الألغاز المنطقية", icon: "🧩", category: "logic" },
      { name: "Reaction Time", description: "اختبر سرعة ردود أفعالك", icon: "⚡", category: "reflex" },
      { name: "Sequence Memory", description: "تذكر التسلسلات", icon: "🔄", category: "sequence" },
    ];

    for (const game of games) {
      await ctx.db.insert("games", game);
    }
  },
});

// Get all games
export const getAllGames = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("games").collect();
  },
});

// Get game by ID
export const getGame = query({
  args: { gameId: v.id("games") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.gameId);
  },
});

// Submit game score
export const submitScore = mutation({
  args: {
    gameId: v.id("games"),
    score: v.number(),
    difficulty: v.string(),
    completionTime: v.optional(v.number()),
    level: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Must be logged in");

    // Insert new score
    await ctx.db.insert("gameScores", {
      gameId: args.gameId,
      userId,
      score: args.score,
      difficulty: args.difficulty,
      completionTime: args.completionTime,
      level: args.level,
    });

    // Update user stats
    const userStats = await ctx.db
      .query("userStats")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (userStats) {
      await ctx.db.patch(userStats._id, {
        totalGamesPlayed: userStats.totalGamesPlayed + 1,
        totalScore: userStats.totalScore + args.score,
      });
    } else {
      await ctx.db.insert("userStats", {
        userId,
        totalGamesPlayed: 1,
        totalScore: args.score,
        achievements: [],
      });
    }
  },
});

// Get leaderboard for a specific game and difficulty
export const getLeaderboard = query({
  args: {
    gameId: v.id("games"),
    difficulty: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    
    const scores = await ctx.db
      .query("gameScores")
      .withIndex("by_game_and_difficulty", (q) => 
        q.eq("gameId", args.gameId).eq("difficulty", args.difficulty)
      )
      .order("desc")
      .take(limit);

    const leaderboard = [];
    for (const score of scores) {
      const user = await ctx.db.get(score.userId);
      if (user) {
        leaderboard.push({
          ...score,
          userName: user.name || user.email || "مجهول",
        });
      }
    }

    return leaderboard;
  },
});

// Get user's best scores
export const getUserBestScores = query({
  args: { gameId: v.optional(v.id("games")) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let query = ctx.db.query("gameScores").withIndex("by_user", (q) => q.eq("userId", userId));
    
    if (args.gameId) {
      query = ctx.db.query("gameScores")
        .withIndex("by_game", (q) => q.eq("gameId", args.gameId))
        .filter((q) => q.eq(q.field("userId"), userId));
    }

    return await query.order("desc").take(20);
  },
});

// Get global leaderboard (top players across all games)
export const getGlobalLeaderboard = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;
    
    const userStats = await ctx.db
      .query("userStats")
      .withIndex("by_total_score", (q) => q.gt("totalScore", 0))
      .order("desc")
      .take(limit);

    const leaderboard = [];
    for (const stats of userStats) {
      const user = await ctx.db.get(stats.userId);
      if (user) {
        leaderboard.push({
          ...stats,
          userName: user.name || user.email || "مجهول",
        });
      }
    }

    return leaderboard;
  },
});
