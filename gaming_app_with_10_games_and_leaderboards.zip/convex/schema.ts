import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  games: defineTable({
    name: v.string(),
    description: v.string(),
    icon: v.string(),
    category: v.string(),
  }),
  
  gameScores: defineTable({
    gameId: v.id("games"),
    userId: v.id("users"),
    score: v.number(),
    difficulty: v.string(), // "easy", "medium", "hard"
    completionTime: v.optional(v.number()),
    level: v.optional(v.number()),
  })
    .index("by_game", ["gameId"])
    .index("by_user", ["userId"])
    .index("by_game_and_difficulty", ["gameId", "difficulty"])
    .index("by_game_score", ["gameId", "score"]),
    
  userStats: defineTable({
    userId: v.id("users"),
    totalGamesPlayed: v.number(),
    totalScore: v.number(),
    favoriteGame: v.optional(v.id("games")),
    achievements: v.array(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_total_score", ["totalScore"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
