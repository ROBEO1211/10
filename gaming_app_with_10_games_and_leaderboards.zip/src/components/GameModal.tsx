import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { Leaderboard } from "./Leaderboard";
import { MemoryGame } from "./games/MemoryGame";
import { NumberPuzzle } from "./games/NumberPuzzle";
import { WordScramble } from "./games/WordScramble";
import { ColorMatch } from "./games/ColorMatch";
import { MathQuiz } from "./games/MathQuiz";
import { PatternRecognition } from "./games/PatternRecognition";
import { SpeedTyping } from "./games/SpeedTyping";
import { LogicPuzzle } from "./games/LogicPuzzle";
import { ReactionTime } from "./games/ReactionTime";
import { SequenceMemory } from "./games/SequenceMemory";
import { toast } from "sonner";

interface GameModalProps {
  gameId: Id<"games">;
  difficulty: string;
  onClose: () => void;
  onDifficultyChange: (difficulty: string) => void;
}

export function GameModal({ gameId, difficulty, onClose, onDifficultyChange }: GameModalProps) {
  const game = useQuery(api.games.getGame, { gameId });
  const submitScore = useMutation(api.games.submitScore);
  
  const [currentView, setCurrentView] = useState<"game" | "leaderboard">("game");
  const [gameStarted, setGameStarted] = useState(false);

  const difficulties = [
    { value: "easy", label: "سهل", color: "bg-green-500" },
    { value: "medium", label: "متوسط", color: "bg-yellow-500" },
    { value: "hard", label: "صعب", color: "bg-red-500" },
  ];

  const handleScoreSubmit = async (score: number, completionTime?: number, level?: number) => {
    try {
      await submitScore({
        gameId,
        score,
        difficulty,
        completionTime,
        level,
      });
      toast.success(`تم حفظ النتيجة: ${score.toLocaleString()} نقطة!`);
    } catch (error) {
      toast.error("حدث خطأ في حفظ النتيجة");
    }
  };

  const renderGame = () => {
    if (!game || !gameStarted) return null;

    const gameProps = {
      difficulty,
      onGameEnd: handleScoreSubmit,
    };

    switch (game.name) {
      case "Memory Match":
        return <MemoryGame {...gameProps} />;
      case "Number Puzzle":
        return <NumberPuzzle {...gameProps} />;
      case "Word Scramble":
        return <WordScramble {...gameProps} />;
      case "Color Match":
        return <ColorMatch {...gameProps} />;
      case "Math Quiz":
        return <MathQuiz {...gameProps} />;
      case "Pattern Recognition":
        return <PatternRecognition {...gameProps} />;
      case "Speed Typing":
        return <SpeedTyping {...gameProps} />;
      case "Logic Puzzle":
        return <LogicPuzzle {...gameProps} />;
      case "Reaction Time":
        return <ReactionTime {...gameProps} />;
      case "Sequence Memory":
        return <SequenceMemory {...gameProps} />;
      default:
        return <div className="text-center text-slate-600">اللعبة غير متاحة حالياً</div>;
    }
  };

  if (!game) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-4xl">{game.icon}</span>
              <div>
                <h2 className="text-2xl font-bold">{game.name}</h2>
                <p className="text-blue-100">{game.description}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Navigation */}
          <div className="flex gap-4 mt-4">
            <button
              onClick={() => setCurrentView("game")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === "game" ? "bg-white text-blue-600" : "bg-white/20 text-white"
              }`}
            >
              اللعبة
            </button>
            <button
              onClick={() => setCurrentView("leaderboard")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === "leaderboard" ? "bg-white text-blue-600" : "bg-white/20 text-white"
              }`}
            >
              قائمة الصدارة
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {currentView === "game" ? (
            <div className="space-y-6">
              {!gameStarted ? (
                <div className="space-y-6">
                  {/* Difficulty Selection */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-slate-800">اختر مستوى الصعوبة:</h3>
                    <div className="flex gap-3">
                      {difficulties.map((diff) => (
                        <button
                          key={diff.value}
                          onClick={() => onDifficultyChange(diff.value)}
                          className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
                            difficulty === diff.value
                              ? `${diff.color} text-white shadow-lg`
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          {diff.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Start Game Button */}
                  <button
                    onClick={() => setGameStarted(true)}
                    className="w-full py-4 bg-gradient-to-r from-green-500 to-green-600 text-white font-bold text-lg rounded-lg hover:from-green-600 hover:to-green-700 transition-all shadow-lg hover:shadow-xl"
                  >
                    ابدأ اللعبة
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-slate-600">المستوى:</span>
                      <span className={`px-2 py-1 rounded text-xs font-semibold text-white ${
                        difficulties.find(d => d.value === difficulty)?.color
                      }`}>
                        {difficulties.find(d => d.value === difficulty)?.label}
                      </span>
                    </div>
                    <button
                      onClick={() => setGameStarted(false)}
                      className="text-slate-600 hover:text-slate-800 text-sm"
                    >
                      العودة للإعدادات
                    </button>
                  </div>
                  {renderGame()}
                </div>
              )}
            </div>
          ) : (
            <Leaderboard gameId={gameId} difficulty={difficulty} />
          )}
        </div>
      </div>
    </div>
  );
}
