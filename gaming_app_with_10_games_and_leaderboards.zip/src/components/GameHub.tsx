import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState, useEffect } from "react";
import { GameCard } from "./GameCard";
import { Leaderboard } from "./Leaderboard";
import { GameModal } from "./GameModal";
import { Id } from "../../convex/_generated/dataModel";

export function GameHub() {
  const games = useQuery(api.games.getAllGames);
  const initializeGames = useMutation(api.games.initializeGames);
  const globalLeaderboard = useQuery(api.games.getGlobalLeaderboard, { limit: 5 });
  
  const [selectedGame, setSelectedGame] = useState<Id<"games"> | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("medium");

  useEffect(() => {
    if (games && games.length === 0) {
      initializeGames();
    }
  }, [games, initializeGames]);

  if (!games) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Global Leaderboard */}
      <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg">
        <h3 className="text-2xl font-bold text-slate-800 mb-4 text-center">
          🏆 قائمة الصدارة العامة
        </h3>
        {globalLeaderboard && globalLeaderboard.length > 0 ? (
          <div className="space-y-3">
            {globalLeaderboard.map((player, index) => (
              <div
                key={player._id}
                className={`flex items-center justify-between p-3 rounded-lg ${
                  index === 0 ? "bg-gradient-to-r from-yellow-100 to-yellow-200 border border-yellow-300" :
                  index === 1 ? "bg-gradient-to-r from-gray-100 to-gray-200 border border-gray-300" :
                  index === 2 ? "bg-gradient-to-r from-orange-100 to-orange-200 border border-orange-300" :
                  "bg-slate-50 border border-slate-200"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">
                    {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `#${index + 1}`}
                  </span>
                  <span className="font-semibold text-slate-800">{player.userName}</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-lg text-slate-800">{player.totalScore.toLocaleString()}</div>
                  <div className="text-sm text-slate-600">{player.totalGamesPlayed} لعبة</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-slate-600">لا توجد نتائج بعد. كن أول من يلعب!</p>
        )}
      </div>

      {/* Games Grid */}
      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-slate-800 text-center">الألعاب المتاحة</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {games.map((game) => (
            <GameCard
              key={game._id}
              game={game}
              onPlay={() => setSelectedGame(game._id)}
            />
          ))}
        </div>
      </div>

      {/* Game Modal */}
      {selectedGame && (
        <GameModal
          gameId={selectedGame}
          difficulty={selectedDifficulty}
          onClose={() => setSelectedGame(null)}
          onDifficultyChange={setSelectedDifficulty}
        />
      )}
    </div>
  );
}
