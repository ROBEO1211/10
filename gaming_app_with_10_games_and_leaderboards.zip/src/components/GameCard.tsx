import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";

interface GameCardProps {
  game: {
    _id: Id<"games">;
    name: string;
    description: string;
    icon: string;
    category: string;
  };
  onPlay: () => void;
}

export function GameCard({ game, onPlay }: GameCardProps) {
  const userBestScores = useQuery(api.games.getUserBestScores, { gameId: game._id });
  
  const bestScore = userBestScores?.length ? Math.max(...userBestScores.map(s => s.score)) : 0;

  const getCategoryColor = (category: string) => {
    const colors = {
      memory: "from-purple-400 to-purple-600",
      puzzle: "from-green-400 to-green-600",
      word: "from-blue-400 to-blue-600",
      reflex: "from-red-400 to-red-600",
      math: "from-orange-400 to-orange-600",
      pattern: "from-pink-400 to-pink-600",
      typing: "from-indigo-400 to-indigo-600",
      logic: "from-teal-400 to-teal-600",
      sequence: "from-cyan-400 to-cyan-600",
    };
    return colors[category as keyof typeof colors] || "from-gray-400 to-gray-600";
  };

  return (
    <div className="group bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div className="space-y-4">
        {/* Game Icon */}
        <div className={`w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br ${getCategoryColor(game.category)} flex items-center justify-center text-3xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
          {game.icon}
        </div>

        {/* Game Info */}
        <div className="text-center space-y-2">
          <h4 className="text-xl font-bold text-slate-800">{game.name}</h4>
          <p className="text-sm text-slate-600 leading-relaxed">{game.description}</p>
        </div>

        {/* Best Score */}
        {bestScore > 0 && (
          <div className="bg-slate-50 rounded-lg p-3 text-center">
            <div className="text-xs text-slate-500 mb-1">أفضل نتيجة</div>
            <div className="text-lg font-bold text-slate-800">{bestScore.toLocaleString()}</div>
          </div>
        )}

        {/* Play Button */}
        <button
          onClick={onPlay}
          className={`w-full py-3 px-4 rounded-xl bg-gradient-to-r ${getCategoryColor(game.category)} text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 active:scale-95`}
        >
          العب الآن
        </button>
      </div>
    </div>
  );
}
