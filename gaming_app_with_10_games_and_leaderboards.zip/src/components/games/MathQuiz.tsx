import { useState, useEffect } from "react";

interface MathQuizProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function MathQuiz({ difficulty, onGameEnd }: MathQuizProps) {
  const [question, setQuestion] = useState("");
  const [correctAnswer, setCorrectAnswer] = useState(0);
  const [options, setOptions] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);

  const totalQuestions = difficulty === "easy" ? 10 : difficulty === "medium" ? 15 : 20;
  const questionTime = difficulty === "easy" ? 15000 : difficulty === "medium" ? 10000 : 8000;

  useEffect(() => {
    startNewGame();
  }, [difficulty]);

  useEffect(() => {
    if (timeLeft > 0 && !gameCompleted && feedback === null) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 100), 100);
      return () => clearTimeout(timer);
    } else if (timeLeft <= 0 && !gameCompleted && feedback === null) {
      handleTimeout();
    }
  }, [timeLeft, gameCompleted, feedback]);

  const startNewGame = () => {
    setScore(0);
    setQuestionNumber(1);
    setStartTime(Date.now());
    setGameCompleted(false);
    generateNewQuestion();
  };

  const generateNewQuestion = () => {
    let num1, num2, operation, answer, questionText;

    if (difficulty === "easy") {
      num1 = Math.floor(Math.random() * 20) + 1;
      num2 = Math.floor(Math.random() * 20) + 1;
      operation = Math.random() < 0.5 ? "+" : "-";
      
      if (operation === "+") {
        answer = num1 + num2;
        questionText = `${num1} + ${num2}`;
      } else {
        if (num1 < num2) [num1, num2] = [num2, num1];
        answer = num1 - num2;
        questionText = `${num1} - ${num2}`;
      }
    } else if (difficulty === "medium") {
      const operations = ["+", "-", "×"];
      operation = operations[Math.floor(Math.random() * operations.length)];
      
      if (operation === "×") {
        num1 = Math.floor(Math.random() * 12) + 1;
        num2 = Math.floor(Math.random() * 12) + 1;
        answer = num1 * num2;
        questionText = `${num1} × ${num2}`;
      } else {
        num1 = Math.floor(Math.random() * 50) + 1;
        num2 = Math.floor(Math.random() * 50) + 1;
        
        if (operation === "+") {
          answer = num1 + num2;
          questionText = `${num1} + ${num2}`;
        } else {
          if (num1 < num2) [num1, num2] = [num2, num1];
          answer = num1 - num2;
          questionText = `${num1} - ${num2}`;
        }
      }
    } else {
      const operations = ["+", "-", "×", "÷"];
      operation = operations[Math.floor(Math.random() * operations.length)];
      
      if (operation === "÷") {
        num2 = Math.floor(Math.random() * 12) + 1;
        answer = Math.floor(Math.random() * 20) + 1;
        num1 = num2 * answer;
        questionText = `${num1} ÷ ${num2}`;
      } else if (operation === "×") {
        num1 = Math.floor(Math.random() * 15) + 1;
        num2 = Math.floor(Math.random() * 15) + 1;
        answer = num1 * num2;
        questionText = `${num1} × ${num2}`;
      } else {
        num1 = Math.floor(Math.random() * 100) + 1;
        num2 = Math.floor(Math.random() * 100) + 1;
        
        if (operation === "+") {
          answer = num1 + num2;
          questionText = `${num1} + ${num2}`;
        } else {
          if (num1 < num2) [num1, num2] = [num2, num1];
          answer = num1 - num2;
          questionText = `${num1} - ${num2}`;
        }
      }
    }

    setQuestion(questionText);
    setCorrectAnswer(answer);
    
    // Generate options
    const wrongAnswers = [];
    while (wrongAnswers.length < 3) {
      const wrong = answer + (Math.floor(Math.random() * 20) - 10);
      if (wrong !== answer && wrong > 0 && !wrongAnswers.includes(wrong)) {
        wrongAnswers.push(wrong);
      }
    }
    
    setOptions([answer, ...wrongAnswers].sort(() => Math.random() - 0.5));
    setTimeLeft(questionTime);
    setFeedback(null);
  };

  const handleAnswerClick = (selectedAnswer: number) => {
    if (feedback !== null) return;

    if (selectedAnswer === correctAnswer) {
      setFeedback("correct");
      const timeBonus = Math.floor(timeLeft / 100);
      const newScore = score + (difficulty === "easy" ? 10 : difficulty === "medium" ? 20 : 30) + timeBonus;
      setScore(newScore);

      setTimeout(() => {
        const newQuestionNumber = questionNumber + 1;
        setQuestionNumber(newQuestionNumber);

        if (newQuestionNumber > totalQuestions) {
          const completionTime = Date.now() - startTime;
          setGameCompleted(true);
          onGameEnd(newScore, completionTime);
        } else {
          generateNewQuestion();
        }
      }, 1500);
    } else {
      setFeedback("incorrect");
      setTimeout(() => {
        const newQuestionNumber = questionNumber + 1;
        setQuestionNumber(newQuestionNumber);

        if (newQuestionNumber > totalQuestions) {
          const completionTime = Date.now() - startTime;
          setGameCompleted(true);
          onGameEnd(score, completionTime);
        } else {
          generateNewQuestion();
        }
      }, 1500);
    }
  };

  const handleTimeout = () => {
    setFeedback("incorrect");
    setTimeout(() => {
      const newQuestionNumber = questionNumber + 1;
      setQuestionNumber(newQuestionNumber);

      if (newQuestionNumber > totalQuestions) {
        const completionTime = Date.now() - startTime;
        setGameCompleted(true);
        onGameEnd(score, completionTime);
      } else {
        generateNewQuestion();
      }
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{score}</div>
          <div className="text-sm text-slate-600">النقاط</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{questionNumber}/{totalQuestions}</div>
          <div className="text-sm text-slate-600">السؤال</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.ceil(timeLeft / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {!gameCompleted ? (
        <div className="space-y-6">
          {/* Time Bar */}
          <div className="w-full bg-slate-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-red-500 h-3 rounded-full transition-all duration-100"
              style={{ width: `${(timeLeft / questionTime) * 100}%` }}
            />
          </div>

          {/* Question */}
          <div className="text-center">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">احسب النتيجة:</h3>
            <div className="text-5xl font-bold text-blue-600 bg-blue-50 rounded-lg p-8">
              {question} = ?
            </div>
          </div>

          {/* Answer Options */}
          <div className="grid grid-cols-2 gap-4">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerClick(option)}
                disabled={feedback !== null}
                className="p-4 text-xl font-semibold bg-white border-2 border-slate-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all disabled:cursor-not-allowed"
              >
                {option}
              </button>
            ))}
          </div>

          {/* Feedback */}
          {feedback && (
            <div className={`text-center p-4 rounded-lg ${
              feedback === "correct" 
                ? "bg-green-100 text-green-800" 
                : "bg-red-100 text-red-800"
            }`}>
              {feedback === "correct" ? (
                <div>
                  <div className="text-2xl mb-2">✅</div>
                  <div className="font-semibold">صحيح! الإجابة هي {correctAnswer}</div>
                </div>
              ) : (
                <div>
                  <div className="text-2xl mb-2">❌</div>
                  <div className="font-semibold">خطأ! الإجابة الصحيحة هي {correctAnswer}</div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🧮</div>
          <h3 className="text-2xl font-bold text-green-800">انتهى الاختبار!</h3>
          <p className="text-green-700">
            أجبت على {totalQuestions} سؤال وحصلت على {score} نقطة
          </p>
          <button
            onClick={startNewGame}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            اختبار جديد
          </button>
        </div>
      )}
    </div>
  );
}
