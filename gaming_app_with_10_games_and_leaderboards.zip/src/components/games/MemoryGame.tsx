import { useState, useEffect } from "react";

interface MemoryGameProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function MemoryGame({ difficulty, onGameEnd }: MemoryGameProps) {
  const [cards, setCards] = useState<{ id: number; symbol: string; isFlipped: boolean; isMatched: boolean }[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);

  const symbols = ["🎮", "🎯", "🎲", "🎪", "🎨", "🎭", "🎪", "🎸", "🎺", "🎻", "🎹", "🎤"];
  
  const gridSize = difficulty === "easy" ? 4 : difficulty === "medium" ? 6 : 8;
  const pairsCount = (gridSize * gridSize) / 2;

  useEffect(() => {
    initializeGame();
  }, [difficulty]);

  const initializeGame = () => {
    const gameSymbols = symbols.slice(0, pairsCount);
    const gameCards = [...gameSymbols, ...gameSymbols]
      .sort(() => Math.random() - 0.5)
      .map((symbol, index) => ({
        id: index,
        symbol,
        isFlipped: false,
        isMatched: false,
      }));
    
    setCards(gameCards);
    setFlippedCards([]);
    setScore(0);
    setMoves(0);
    setStartTime(Date.now());
    setGameCompleted(false);
  };

  const handleCardClick = (cardId: number) => {
    if (flippedCards.length === 2 || cards[cardId].isFlipped || cards[cardId].isMatched) {
      return;
    }

    const newFlippedCards = [...flippedCards, cardId];
    setFlippedCards(newFlippedCards);

    setCards(prev => prev.map(card => 
      card.id === cardId ? { ...card, isFlipped: true } : card
    ));

    if (newFlippedCards.length === 2) {
      setMoves(prev => prev + 1);
      
      setTimeout(() => {
        const [firstId, secondId] = newFlippedCards;
        const firstCard = cards[firstId];
        const secondCard = cards[secondId];

        if (firstCard.symbol === secondCard.symbol) {
          setCards(prev => prev.map(card => 
            card.id === firstId || card.id === secondId 
              ? { ...card, isMatched: true }
              : card
          ));
          
          const newScore = score + (difficulty === "easy" ? 10 : difficulty === "medium" ? 20 : 30);
          setScore(newScore);

          // Check if game is completed
          const matchedCount = cards.filter(card => card.isMatched).length + 2;
          if (matchedCount === cards.length) {
            const completionTime = Date.now() - startTime;
            const timeBonus = Math.max(0, 60000 - completionTime) / 1000;
            const finalScore = Math.round(newScore + timeBonus);
            setGameCompleted(true);
            onGameEnd(finalScore, completionTime);
          }
        } else {
          setCards(prev => prev.map(card => 
            card.id === firstId || card.id === secondId 
              ? { ...card, isFlipped: false }
              : card
          ));
        }
        
        setFlippedCards([]);
      }, 1000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{score}</div>
          <div className="text-sm text-slate-600">النقاط</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{moves}</div>
          <div className="text-sm text-slate-600">المحاولات</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.floor((Date.now() - startTime) / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {/* Game Board */}
      <div 
        className="grid gap-3 mx-auto max-w-lg"
        style={{ 
          gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
        }}
      >
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            disabled={card.isFlipped || card.isMatched || gameCompleted}
            className={`aspect-square rounded-lg text-2xl font-bold transition-all duration-300 ${
              card.isFlipped || card.isMatched
                ? card.isMatched 
                  ? "bg-green-200 text-green-800 scale-105"
                  : "bg-blue-200 text-blue-800"
                : "bg-slate-200 hover:bg-slate-300 active:scale-95"
            }`}
          >
            {card.isFlipped || card.isMatched ? card.symbol : "?"}
          </button>
        ))}
      </div>

      {gameCompleted && (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🎉</div>
          <h3 className="text-2xl font-bold text-green-800">تهانينا!</h3>
          <p className="text-green-700">
            أكملت اللعبة في {moves} محاولة و {Math.floor((Date.now() - startTime) / 1000)} ثانية
          </p>
          <button
            onClick={initializeGame}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            العب مرة أخرى
          </button>
        </div>
      )}
    </div>
  );
}
