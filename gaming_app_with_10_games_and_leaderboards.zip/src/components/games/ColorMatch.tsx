import { useState, useEffect } from "react";

interface ColorMatchProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function ColorMatch({ difficulty, onGameEnd }: ColorMatchProps) {
  const [targetColor, setTargetColor] = useState("");
  const [colorOptions, setColorOptions] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);

  const colors = [
    { name: "أحمر", value: "#ef4444", nameEn: "red" },
    { name: "أزرق", value: "#3b82f6", nameEn: "blue" },
    { name: "أخضر", value: "#10b981", nameEn: "green" },
    { name: "أصفر", value: "#f59e0b", nameEn: "yellow" },
    { name: "بنفسجي", value: "#8b5cf6", nameEn: "purple" },
    { name: "برتقالي", value: "#f97316", nameEn: "orange" },
    { name: "وردي", value: "#ec4899", nameEn: "pink" },
    { name: "بني", value: "#a3a3a3", nameEn: "brown" },
  ];

  const totalRounds = difficulty === "easy" ? 10 : difficulty === "medium" ? 15 : 20;
  const roundTime = difficulty === "easy" ? 5000 : difficulty === "medium" ? 3000 : 2000;

  useEffect(() => {
    startNewGame();
  }, [difficulty]);

  useEffect(() => {
    if (timeLeft > 0 && !gameCompleted && feedback === null) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 100), 100);
      return () => clearTimeout(timer);
    } else if (timeLeft <= 0 && !gameCompleted && feedback === null) {
      handleTimeout();
    }
  }, [timeLeft, gameCompleted, feedback]);

  const startNewGame = () => {
    setScore(0);
    setRound(1);
    setStartTime(Date.now());
    setGameCompleted(false);
    generateNewRound();
  };

  const generateNewRound = () => {
    const target = colors[Math.floor(Math.random() * colors.length)];
    setTargetColor(target.name);
    
    const optionsCount = difficulty === "easy" ? 3 : difficulty === "medium" ? 4 : 6;
    const options = [target];
    
    while (options.length < optionsCount) {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      if (!options.find(c => c.nameEn === randomColor.nameEn)) {
        options.push(randomColor);
      }
    }
    
    setColorOptions(options.sort(() => Math.random() - 0.5));
    setTimeLeft(roundTime);
    setFeedback(null);
  };

  const handleColorClick = (selectedColor: typeof colors[0]) => {
    if (feedback !== null) return;

    if (selectedColor.name === targetColor) {
      setFeedback("correct");
      const timeBonus = Math.floor(timeLeft / 100);
      const newScore = score + (difficulty === "easy" ? 10 : difficulty === "medium" ? 20 : 30) + timeBonus;
      setScore(newScore);

      setTimeout(() => {
        const newRound = round + 1;
        setRound(newRound);

        if (newRound > totalRounds) {
          const completionTime = Date.now() - startTime;
          setGameCompleted(true);
          onGameEnd(newScore, completionTime);
        } else {
          generateNewRound();
        }
      }, 1000);
    } else {
      setFeedback("incorrect");
      setTimeout(() => {
        generateNewRound();
      }, 1000);
    }
  };

  const handleTimeout = () => {
    setFeedback("incorrect");
    setTimeout(() => {
      const newRound = round + 1;
      setRound(newRound);

      if (newRound > totalRounds) {
        const completionTime = Date.now() - startTime;
        setGameCompleted(true);
        onGameEnd(score, completionTime);
      } else {
        generateNewRound();
      }
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{score}</div>
          <div className="text-sm text-slate-600">النقاط</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{round}/{totalRounds}</div>
          <div className="text-sm text-slate-600">الجولة</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.ceil(timeLeft / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {!gameCompleted ? (
        <div className="space-y-6">
          {/* Time Bar */}
          <div className="w-full bg-slate-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-red-500 h-3 rounded-full transition-all duration-100"
              style={{ width: `${(timeLeft / roundTime) * 100}%` }}
            />
          </div>

          {/* Target Color */}
          <div className="text-center">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">اختر اللون:</h3>
            <div className="text-4xl font-bold text-slate-800 bg-slate-100 rounded-lg p-6">
              {targetColor}
            </div>
          </div>

          {/* Color Options */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {colorOptions.map((color, index) => (
              <button
                key={index}
                onClick={() => handleColorClick(color)}
                disabled={feedback !== null}
                className="aspect-square rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 disabled:cursor-not-allowed"
                style={{ backgroundColor: color.value }}
              />
            ))}
          </div>

          {/* Feedback */}
          {feedback && (
            <div className={`text-center p-4 rounded-lg ${
              feedback === "correct" 
                ? "bg-green-100 text-green-800" 
                : "bg-red-100 text-red-800"
            }`}>
              {feedback === "correct" ? (
                <div>
                  <div className="text-2xl mb-2">✅</div>
                  <div className="font-semibold">صحيح!</div>
                </div>
              ) : (
                <div>
                  <div className="text-2xl mb-2">❌</div>
                  <div className="font-semibold">خطأ أو انتهى الوقت!</div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🎨</div>
          <h3 className="text-2xl font-bold text-green-800">انتهت اللعبة!</h3>
          <p className="text-green-700">
            أكملت {totalRounds} جولة بنتيجة {score} نقطة
          </p>
          <button
            onClick={startNewGame}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            لعبة جديدة
          </button>
        </div>
      )}
    </div>
  );
}
