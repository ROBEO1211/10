import { useState, useEffect } from "react";

interface WordScrambleProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function WordScramble({ difficulty, onGameEnd }: WordScrambleProps) {
  const [currentWord, setCurrentWord] = useState("");
  const [scrambledWord, setScrambledWord] = useState("");
  const [userInput, setUserInput] = useState("");
  const [score, setScore] = useState(0);
  const [wordsCompleted, setWordsCompleted] = useState(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);

  const words = {
    easy: ["كتاب", "قلم", "بيت", "شمس", "قمر", "ماء", "نار", "ورد", "طير", "سمك"],
    medium: ["مدرسة", "مكتبة", "حديقة", "مطبخ", "حاسوب", "تلفاز", "هاتف", "طائرة", "سيارة", "قطار"],
    hard: ["جامعة", "مستشفى", "مطعم", "متحف", "مكتب", "مصنع", "محطة", "مطار", "ميناء", "سوق"]
  };

  const wordsToComplete = difficulty === "easy" ? 5 : difficulty === "medium" ? 7 : 10;

  useEffect(() => {
    startNewGame();
  }, [difficulty]);

  const startNewGame = () => {
    setScore(0);
    setWordsCompleted(0);
    setStartTime(Date.now());
    setGameCompleted(false);
    generateNewWord();
  };

  const generateNewWord = () => {
    const wordList = words[difficulty as keyof typeof words];
    const randomWord = wordList[Math.floor(Math.random() * wordList.length)];
    setCurrentWord(randomWord);
    setScrambledWord(scrambleWord(randomWord));
    setUserInput("");
    setFeedback(null);
  };

  const scrambleWord = (word: string) => {
    const letters = word.split("");
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    return letters.join("");
  };

  const handleSubmit = () => {
    if (userInput.trim() === currentWord) {
      setFeedback("correct");
      const newScore = score + (difficulty === "easy" ? 10 : difficulty === "medium" ? 20 : 30);
      setScore(newScore);
      const newWordsCompleted = wordsCompleted + 1;
      setWordsCompleted(newWordsCompleted);

      if (newWordsCompleted >= wordsToComplete) {
        const completionTime = Date.now() - startTime;
        const timeBonus = Math.max(0, 180000 - completionTime) / 1000;
        const finalScore = Math.round(newScore + timeBonus);
        setGameCompleted(true);
        onGameEnd(finalScore, completionTime);
      } else {
        setTimeout(() => {
          generateNewWord();
        }, 1500);
      }
    } else {
      setFeedback("incorrect");
      setTimeout(() => {
        setFeedback(null);
        setUserInput("");
      }, 1500);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit();
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{score}</div>
          <div className="text-sm text-slate-600">النقاط</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{wordsCompleted}/{wordsToComplete}</div>
          <div className="text-sm text-slate-600">الكلمات</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.floor((Date.now() - startTime) / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {!gameCompleted ? (
        <div className="space-y-6">
          {/* Scrambled Word */}
          <div className="text-center">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">رتب الحروف لتكوين كلمة:</h3>
            <div className="text-4xl font-bold text-blue-600 bg-blue-50 rounded-lg p-6 tracking-wider">
              {scrambledWord}
            </div>
          </div>

          {/* Input */}
          <div className="space-y-4">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="اكتب الكلمة الصحيحة..."
              className="w-full p-4 text-xl text-center border-2 border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none"
              disabled={feedback !== null}
            />
            
            <button
              onClick={handleSubmit}
              disabled={!userInput.trim() || feedback !== null}
              className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              تأكيد
            </button>
          </div>

          {/* Feedback */}
          {feedback && (
            <div className={`text-center p-4 rounded-lg ${
              feedback === "correct" 
                ? "bg-green-100 text-green-800" 
                : "bg-red-100 text-red-800"
            }`}>
              {feedback === "correct" ? (
                <div>
                  <div className="text-2xl mb-2">✅</div>
                  <div className="font-semibold">صحيح! الكلمة هي: {currentWord}</div>
                </div>
              ) : (
                <div>
                  <div className="text-2xl mb-2">❌</div>
                  <div className="font-semibold">خطأ! حاول مرة أخرى</div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🎉</div>
          <h3 className="text-2xl font-bold text-green-800">رائع!</h3>
          <p className="text-green-700">
            أكملت {wordsToComplete} كلمة في {Math.floor((Date.now() - startTime) / 1000)} ثانية
          </p>
          <button
            onClick={startNewGame}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            لعبة جديدة
          </button>
        </div>
      )}
    </div>
  );
}
