import { useState, useEffect } from "react";

interface NumberPuzzleProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function NumberPuzzle({ difficulty, onGameEnd }: NumberPuzzleProps) {
  const [puzzle, setPuzzle] = useState<(number | null)[]>([]);
  const [moves, setMoves] = useState(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);

  const size = difficulty === "easy" ? 3 : difficulty === "medium" ? 4 : 5;
  const totalTiles = size * size;

  useEffect(() => {
    initializePuzzle();
  }, [difficulty]);

  const initializePuzzle = () => {
    const numbers = Array.from({ length: totalTiles - 1 }, (_, i) => i + 1);
    numbers.push(null); // Empty space
    
    // Shuffle the puzzle
    for (let i = 0; i < 1000; i++) {
      const emptyIndex = numbers.indexOf(null);
      const possibleMoves = getPossibleMoves(emptyIndex);
      const randomMove = possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
      [numbers[emptyIndex], numbers[randomMove]] = [numbers[randomMove], numbers[emptyIndex]];
    }
    
    setPuzzle(numbers);
    setMoves(0);
    setStartTime(Date.now());
    setGameCompleted(false);
  };

  const getPossibleMoves = (emptyIndex: number) => {
    const moves = [];
    const row = Math.floor(emptyIndex / size);
    const col = emptyIndex % size;

    if (row > 0) moves.push(emptyIndex - size); // Up
    if (row < size - 1) moves.push(emptyIndex + size); // Down
    if (col > 0) moves.push(emptyIndex - 1); // Left
    if (col < size - 1) moves.push(emptyIndex + 1); // Right

    return moves;
  };

  const handleTileClick = (index: number) => {
    if (gameCompleted || puzzle[index] === null) return;

    const emptyIndex = puzzle.indexOf(null);
    const possibleMoves = getPossibleMoves(emptyIndex);

    if (possibleMoves.includes(index)) {
      const newPuzzle = [...puzzle];
      [newPuzzle[emptyIndex], newPuzzle[index]] = [newPuzzle[index], newPuzzle[emptyIndex]];
      setPuzzle(newPuzzle);
      setMoves(prev => prev + 1);

      // Check if puzzle is solved
      const isSolved = newPuzzle.slice(0, -1).every((num, i) => num === i + 1);
      if (isSolved) {
        const completionTime = Date.now() - startTime;
        const timeBonus = Math.max(0, 120000 - completionTime) / 1000;
        const movesPenalty = moves * 2;
        const difficultyMultiplier = difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3;
        const score = Math.round((1000 + timeBonus - movesPenalty) * difficultyMultiplier);
        
        setGameCompleted(true);
        onGameEnd(Math.max(score, 100), completionTime);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{moves}</div>
          <div className="text-sm text-slate-600">الحركات</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.floor((Date.now() - startTime) / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {/* Puzzle Grid */}
      <div 
        className="grid gap-2 mx-auto max-w-sm"
        style={{ 
          gridTemplateColumns: `repeat(${size}, 1fr)`,
        }}
      >
        {puzzle.map((number, index) => (
          <button
            key={index}
            onClick={() => handleTileClick(index)}
            disabled={gameCompleted}
            className={`aspect-square rounded-lg text-xl font-bold transition-all duration-200 ${
              number === null
                ? "bg-slate-100"
                : "bg-blue-500 text-white hover:bg-blue-600 active:scale-95 shadow-lg"
            }`}
          >
            {number}
          </button>
        ))}
      </div>

      {/* Instructions */}
      <div className="text-center text-sm text-slate-600 bg-slate-50 rounded-lg p-4">
        <p>انقر على الأرقام المجاورة للمساحة الفارغة لتحريكها</p>
        <p>رتب الأرقام من 1 إلى {totalTiles - 1} بأقل عدد من الحركات</p>
      </div>

      {gameCompleted && (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🎉</div>
          <h3 className="text-2xl font-bold text-green-800">ممتاز!</h3>
          <p className="text-green-700">
            حللت اللغز في {moves} حركة و {Math.floor((Date.now() - startTime) / 1000)} ثانية
          </p>
          <button
            onClick={initializePuzzle}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            لغز جديد
          </button>
        </div>
      )}
    </div>
  );
}
