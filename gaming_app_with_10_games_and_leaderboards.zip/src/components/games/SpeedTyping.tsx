import { useState, useEffect } from "react";

interface SpeedTypingProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function SpeedTyping({ difficulty, onGameEnd }: SpeedTypingProps) {
  const [targetText, setTargetText] = useState("");
  const [userInput, setUserInput] = useState("");
  const [startTime, setStartTime] = useState<number>(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameCompleted, setGameCompleted] = useState(false);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [errors, setErrors] = useState(0);

  const texts = {
    easy: [
      "القط يلعب في الحديقة",
      "الشمس تشرق في الصباح",
      "الطيور تغرد فوق الشجرة",
      "الما