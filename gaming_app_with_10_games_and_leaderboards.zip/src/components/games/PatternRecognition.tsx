import { useState, useEffect } from "react";

interface PatternRecognitionProps {
  difficulty: string;
  onGameEnd: (score: number, completionTime: number) => void;
}

export function PatternRecognition({ difficulty, onGameEnd }: PatternRecognitionProps) {
  const [pattern, setPattern] = useState<string[]>([]);
  const [options, setOptions] = useState<string[]>([]);
  const [correctAnswer, setCorrectAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [gameCompleted, setGameCompleted] = useState(false);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);

  const shapes = ["🔴", "🔵", "🟡", "🟢", "🟣", "🟠", "⚫", "⚪"];
  const totalRounds = difficulty === "easy" ? 8 : difficulty === "medium" ? 12 : 16;

  useEffect(() => {
    startNewGame();
  }, [difficulty]);

  const startNewGame = () => {
    setScore(0);
    setRound(1);
    setStartTime(Date.now());
    setGameCompleted(false);
    generateNewPattern();
  };

  const generateNewPattern = () => {
    const patternLength = difficulty === "easy" ? 4 : difficulty === "medium" ? 6 : 8;
    const availableShapes = shapes.slice(0, difficulty === "easy" ? 4 : difficulty === "medium" ? 6 : 8);
    
    // Generate a pattern with a logical sequence
    const newPattern = [];
    const patternType = Math.floor(Math.random() * 3); // 0: repeating, 1: alternating, 2: sequence
    
    if (patternType === 0) {
      // Repeating pattern (AB AB AB)
      const base = [
        availableShapes[Math.floor(Math.random() * availableShapes.length)],
        availableShapes[Math.floor(Math.random() * availableShapes.length)]
      ];
      for (let i = 0; i < patternLength - 1; i++) {
        newPattern.push(base[i % base.length]);
      }
      setCorrectAnswer(base[(patternLength - 1) % base.length]);
    } else if (patternType === 1) {
      // Alternating pattern (A B A B A)
      const shapeA = availableShapes[Math.floor(Math.random() * availableShapes.length)];
      let shapeB = availableShapes[Math.floor(Math.random() * availableShapes.length)];
      while (shapeB === shapeA) {
        shapeB = availableShapes[Math.floor(Math.random() * availableShapes.length)];
      }
      
      for (let i = 0; i < patternLength - 1; i++) {
        newPattern.push(i % 2 === 0 ? shapeA : shapeB);
      }
      setCorrectAnswer((patternLength - 1) % 2 === 0 ? shapeA : shapeB);
    } else {
      // Sequential pattern (A A B B C C)
      const baseShapes = availableShapes.slice(0, 3);
      for (let i = 0; i < patternLength - 1; i++) {
        newPattern.push(baseShapes[Math.floor(i / 2) % baseShapes.length]);
      }
      setCorrectAnswer(baseShapes[Math.floor((patternLength - 1) / 2) % baseShapes.length]);
    }

    setPattern(newPattern);
    
    // Generate options
    const wrongOptions = [];
    while (wrongOptions.length < 3) {
      const randomShape = availableShapes[Math.floor(Math.random() * availableShapes.length)];
      if (randomShape !== correctAnswer && !wrongOptions.includes(randomShape)) {
        wrongOptions.push(randomShape);
      }
    }
    
    setOptions([correctAnswer, ...wrongOptions].sort(() => Math.random() - 0.5));
    setFeedback(null);
  };

  const handleOptionClick = (selectedOption: string) => {
    if (feedback !== null) return;

    if (selectedOption === correctAnswer) {
      setFeedback("correct");
      const newScore = score + (difficulty === "easy" ? 15 : difficulty === "medium" ? 25 : 35);
      setScore(newScore);

      setTimeout(() => {
        const newRound = round + 1;
        setRound(newRound);

        if (newRound > totalRounds) {
          const completionTime = Date.now() - startTime;
          setGameCompleted(true);
          onGameEnd(newScore, completionTime);
        } else {
          generateNewPattern();
        }
      }, 1500);
    } else {
      setFeedback("incorrect");
      setTimeout(() => {
        const newRound = round + 1;
        setRound(newRound);

        if (newRound > totalRounds) {
          const completionTime = Date.now() - startTime;
          setGameCompleted(true);
          onGameEnd(score, completionTime);
        } else {
          generateNewPattern();
        }
      }, 1500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="flex justify-between items-center bg-slate-50 rounded-lg p-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{score}</div>
          <div className="text-sm text-slate-600">النقاط</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{round}/{totalRounds}</div>
          <div className="text-sm text-slate-600">الجولة</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.floor((Date.now() - startTime) / 1000)}
          </div>
          <div className="text-sm text-slate-600">ثانية</div>
        </div>
      </div>

      {!gameCompleted ? (
        <div className="space-y-6">
          {/* Pattern Display */}
          <div className="text-center">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">ما هو الشكل التالي في النمط؟</h3>
            <div className="bg-slate-100 rounded-lg p-6 mb-4">
              <div className="flex justify-center items-center gap-3 text-4xl">
                {pattern.map((shape, index) => (
                  <span key={index}>{shape}</span>
                ))}
                <span className="text-slate-400">?</span>
              </div>
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionClick(option)}
                disabled={feedback !== null}
                className="aspect-square text-4xl bg-white border-2 border-slate-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all disabled:cursor-not-allowed flex items-center justify-center"
              >
                {option}
              </button>
            ))}
          </div>

          {/* Feedback */}
          {feedback && (
            <div className={`text-center p-4 rounded-lg ${
              feedback === "correct" 
                ? "bg-green-100 text-green-800" 
                : "bg-red-100 text-red-800"
            }`}>
              {feedback === "correct" ? (
                <div>
                  <div className="text-2xl mb-2">✅</div>
                  <div className="font-semibold">صحيح! الشكل التالي هو {correctAnswer}</div>
                </div>
              ) : (
                <div>
                  <div className="text-2xl mb-2">❌</div>
                  <div className="font-semibold">خطأ! الشكل الصحيح هو {correctAnswer}</div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center space-y-4 bg-green-50 rounded-lg p-6">
          <div className="text-4xl">🔍</div>
          <h3 className="text-2xl font-bold text-green-800">انتهت اللعبة!</h3>
          <p className="text-green-700">
            أكملت {totalRounds} نمط وحصلت على {score} نقطة
          </p>
          <button
            onClick={startNewGame}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            لعبة جديدة
          </button>
        </div>
      )}
    </div>
  );
}
