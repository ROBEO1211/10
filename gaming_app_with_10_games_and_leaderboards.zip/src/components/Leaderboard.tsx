import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";

interface LeaderboardProps {
  gameId: Id<"games">;
  difficulty: string;
}

export function Leaderboard({ gameId, difficulty }: LeaderboardProps) {
  const leaderboard = useQuery(api.games.getLeaderboard, { gameId, difficulty, limit: 10 });

  const difficulties = {
    easy: { label: "سهل", color: "bg-green-500" },
    medium: { label: "متوسط", color: "bg-yellow-500" },
    hard: { label: "صعب", color: "bg-red-500" },
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-2xl font-bold text-slate-800 mb-2">قائمة الصدارة</h3>
        <div className="flex justify-center">
          <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
            difficulties[difficulty as keyof typeof difficulties]?.color
          }`}>
            المستوى: {difficulties[difficulty as keyof typeof difficulties]?.label}
          </span>
        </div>
      </div>

      {leaderboard && leaderboard.length > 0 ? (
        <div className="space-y-3">
          {leaderboard.map((entry, index) => (
            <div
              key={entry._id}
              className={`flex items-center justify-between p-4 rounded-lg border ${
                index === 0 ? "bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300" :
                index === 1 ? "bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300" :
                index === 2 ? "bg-gradient-to-r from-orange-50 to-orange-100 border-orange-300" :
                "bg-slate-50 border-slate-200"
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="text-2xl">
                  {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : 
                   <span className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center text-sm font-bold text-slate-700">
                     {index + 1}
                   </span>
                  }
                </div>
                <div>
                  <div className="font-semibold text-slate-800">{entry.userName}</div>
                  <div className="text-sm text-slate-600">
                    {entry.completionTime && `${(entry.completionTime / 1000).toFixed(1)} ثانية`}
                    {entry.level && ` • المستوى ${entry.level}`}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-slate-800">{entry.score.toLocaleString()}</div>
                <div className="text-xs text-slate-500">
                  {new Date(entry._creationTime).toLocaleDateString('ar-SA')}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🏆</div>
          <h4 className="text-xl font-semibold text-slate-800 mb-2">لا توجد نتائج بعد</h4>
          <p className="text-slate-600">كن أول من يحقق نتيجة في هذا المستوى!</p>
        </div>
      )}
    </div>
  );
}
